function register(data){

return ff
}

function login(data){
return dd
}

module.exports = {
    register
};